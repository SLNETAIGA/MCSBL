load "MCSBL.CLASS.rb"

def repl
print "\n>> "
i = STDIN.gets.chomp rescue exit
MCSBL.new(i).run
repl
end

logo

begin
if ARGF.argv[0] != nil
s = MCSBL.new(ARGF.argv[0].read).run
else
puts "Unable to open file."
puts "Usage: MCSBL <source>"
puts "repl started."
repl
end
rescue Exception => e  
  puts "MCSBL: Err: #{e.message}"
end