#coding: utf-8
# MCSBL (c) Zonald Haider
# web: http://absurdlangscollection.comuf.com/MCSBL/
# Mathematical Concatenative Stack Based Language
# Official interpreter
# Licensed under WTFPL(http://www.wtfpl.net/)
def Num n
  (n = Float n) % 1 > 0 ? n : n.to_i
end
def sprint(*args)
  print *args
  puts
end
def sayar(arr)
  for value in arr
    print "#{value}"
  end
end

# SPEC
def factorial n
  n > 1 ? n * factorial(n - 1) : 1
end
def gcd(a, b)
  return a if b.zero?
  gcd(b, a % b)
end
def fibonacci(n)
   n <= 1 ? n :  fibonacci( n - 1 ) + fibonacci( n - 2 ) 
end
  def prime? n
    prime = true
    for r in 2..Math.sqrt(n).to_i
      if (n % r == 0)
        prime = false
        break
      end
    end
    return prime
  end
def logo
	sprint("MCSBL (c) 2016 Zonald Haider  <zonaldhaider@scottishmail.co.uk>")
    sprint("Web: absurdlangscollection.comuf.com/MCSBL")
	sprint("")
end
  
class MCSBL
  S, V, L = [], {}, {}

  Fals = {0 => 1, false => 1, '' => 1}
 

  def initialize src
    if V.empty?
      src.gsub! /(;.*\n|(".*"))/, '\2'
      src.gsub! /\:(\S+)(.+?\n\n)/m do
        V[$~[1]] = MCSBL.new $~[2] 
        nil
      end
    end

    @terms = src.scan(/"[^"]*"|\S+/).map do |t|
      Num t rescue t.delete!('"') || t.to_sym
    end

    i, @I, w, ws = [], {}, [], {}
    @terms.each_with_index do |t, o|
      next unless Symbol === t
      i << [o] if t == :if
      i[-1].concat [o, o] if t == :else
      @I.update Hash[*i.pop << o] if t == :end_if
      w << o if t == :do
      ws[o] = w.pop if t == :end_do
    end

    @W = ws.update ws.invert
  end

  def to_s
    S << @terms; ''
  end

  def run
    ip = -1 
    while (ip+=1) < @terms.size
      case term = @terms[ip]
      when Numeric, String; S << term 
      when /@(\S+)/; V[$1].run() 
      
      # Math
      when :"-";    S << S.pop.to_i - S.pop
      when :"+";    S << S.pop.to_i + S.pop.to_i
      when :"/";    S << S.pop.to_i / S.pop.to_i
      when :"*";    S << S.pop.to_i * S.pop.to_i
      when :"%";    S << S.pop.to_i % S.pop.to_i
	  
      when :"&";    S << S.pop.to_i & S.pop.to_i
	  when :"|";    S << S.pop.to_i | S.pop.to_i
	  when :"<<";    S << S.pop.to_i << S.pop.to_i
	  when :">>";    S << S.pop.to_i >> S.pop.to_i
      when :"^";    S << S.pop.to_i ^ S.pop.to_i
      when :~; S << ~S.pop.to_i
      
      # SPEC
      when :pow; S << S.pop.to_i**S.pop.to_i
      when :fact; S << fact(S.pop.to_i)
      when :sqrt; S << Math.sqrt(S.pop.to_i)
      when :cbrt; S << Math.cbrt(S.pop.to_i)
      when :sin; S << Math.sin(S.pop.to_i)
      when :sinh; S << Math.sinh(S.pop.to_i)
      when :tan; S << Math.tan(S.pop.to_i)
      when :atan; S << Math.atan(S.pop.to_i)
      when :atanh; S << Math.atanh(S.pop.to_i)
      when :atan2; S << Math.atan2(S.pop.to_i)
      when :tanh; S << Math.tanh(S.pop.to_i)
      when :cos; S << Math.cos(S.pop.to_i)
      when :acosh; S << Math.acosh(S.pop.to_i)
      when :gamma; S << Math.gamma(S.pop.to_i)
      when :lgamma; S << Math.lgamma(S.pop.to_i)
      when :log; S << Math.log(S.pop.to_i,S.pop.to_i)
	  when :abs; S << S.pop.abs;
      when :exp; S << Math.exp(S.pop.to_i)
      when :hypot; S << Math.hypot(S.pop.to_i,S.pop.to_i)
      when :gcd; S << gcd(S.pop.to_i,S.pop.to_i)
	  when :lcm; S << S.pop.to_i.lcm(S.pop.to_i)
	  when :next; S << S.pop.to_i.next
	  when :fib; S << fibonacci(S.pop.to_i)
	  when :isprime; S << prime?(S.pop.to_i)
	  when :round;   S << S.pop.to_i.round(S.pop.to_i)
	  when :iseven;    S << S.pop.to_i.even?
	  when :isodd;    S << S.pop.to_i.odd?
     
      # Strings
      when :ord;  S << S.pop.ord
      when :to_s; S << S.pop.to_s
      when :to_i; S << S.pop.to_i
	  when :to_bi; S << S.pop.to_s(S.pop.to_i)
	  when :to_r; S << S.pop.to_i.to_r
	  when :to_f; S << S.pop.to_f
      when :len; S << S[-1].size
	  when :s_to_lower; S << S.pop.to_s.downcase
	  when :s_to_upper; S << S.pop.to_s.upcase
	  when :getchr;      S << S.pop.to_s[S.pop.to_i]
	  when :reverse;     S << S.pop.to_s.reverse
	  when :scan;        S << S.pop.to_s.scan(S.pop.to_s).size
      when :index; S << S[-2][S.pop]
      when :char;   S << ('' << S.pop)
      when :cat;   S << S.pop(2).join

      # STACK
      when :pop;    S.pop
      when :rand;   S << rand
	  when :randn;  S << rand(S.pop.to_i)
	  when :randr;  r = Random.new
	                S << r.rand(S.pop.to_i...S.pop.to_i)
      when :dup;    S << S[-1]
      when :size;   S << S.size
      when :swap;   S.insert(-2, S.pop)
      when :roll;   (n = S.pop) > 0 ?
                    S << S.delete_at(-n) :
                    S.insert(n, S.pop)
      when :over;   S.push(S[-1])
      when :drop;   S.delete_at(-1)
      when :pick;   S.push(S[-S.pop])
      when :picke;  S.push(S[S.pop])
      when :gend;   S.push(S[0])
      when :drope;  S.delete_at(0)
      when :new;    S << Class.const_get(S.pop.capitalize).new
      when :push;   S[-2] << S.pop
      when :sum;    S << S[-1].reduce(:+)
      when :join;   S << S.pop(2).reduce(:*)
      
      # VARS
      when :inc;  V[S.pop] += 1
      when :dec;  V[S.pop] -= 1
      when :def;  V[S.pop] = S.pop
      when :get; S << V[S.pop]
      
      # COMPARION
      when :greater; S << (S.pop <  S.pop)
      when :equal; S << (S.pop == S.pop)
      when :and; S <<(S.pop and S.pop)
      when :or; S << (S.pop or S.pop)
      when :less; S << (S.pop  > S.pop)
	  when :lesseq; S << (S.pop <= S.pop)
	  when :greatereq; S << (S.pop >= S.pop)
      when :not; S << Fals[S.pop].to_i
    
      # OTHER
      when :eval;   MCSBL.new(S.pop).run
	  when :halt;   raise "Stoped by halt"
	  
	  when :label;  L[S.pop] = ip
	  when :goto;   ip = L[S.pop]
      
      # I/O
      when :print; print S.pop
      when :println; sprint(S.pop)
      when :accept; i = STDIN.gets.chomp rescue exit
                    S << i
      when :".";    print S[-1]
      when :".s";   sayar(S)
      when :".st";  print S
      when :cr;     print ('' << 10)
      
      # IF/DO
      when /(end_)?do/
                  ip = @W[ip] if Fals[S.pop] == ($1 ? nil : 1)
      when :if;   ip = @I[ip] if Fals[S.pop]
      when :else; ip = @I[ip]
      when :end_if;  # NOP
      when :nop;  # NOP     

      else raise "Unknown term: '#{term}'"
      end

    end
  end
end